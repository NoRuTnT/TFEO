import React from 'react';
import '../styles/MainPage.css';

const MainPage: React.FC = () => {
  const images = ['/test/home1.png', '/test/home2.png', '/test/home3.png'];

  return (
    <div className="main-page">
      <div className="background-image-container">
        <img src="/assets/mainLogo.png" alt="로고 이미지" />
      </div>

      <div className="background-image-container">
        <img src="/assets/mainBanner.png" alt="배경 이미지" />
      </div>

      <footer className="footer">
        <div className="icon-container">
          <img src="/assets/icons/footer/homeIcon.png" alt="홈" />
          <span className="icon-description">홈</span>
        </div>
        <div className="icon-container">
          <img src="/assets/icons/footer/findHomeIcon.png" alt="집찾기" />
          <span className="icon-description">집찾기</span>
        </div>
        <div className="icon-container">
          <img src="/assets/icons/footer/wishIcon.png" alt="찜목록" />
          <span className="icon-description">찜목록</span>
        </div>
        <div className="icon-container">
          <img src="/assets/icons/footer/menuIcon.png" alt="메뉴" />
          <span className="icon-description">메뉴</span>
        </div>
        <div className="icon-container">
          <img src="/assets/icons/footer/infoIcon.png" alt="내 정보" />
          <span className="icon-description">내 정보</span>
        </div>
      </footer>
    </div>
  );
};

export default MainPage;
