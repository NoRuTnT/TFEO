import React from 'react';
import MainPage from './pages/MainPage';
function App() {
  return (
    <div className="App">
      <MainPage />
      <h2>A707</h2>
    </div>
  );
}

export default App;
